using System.Collections.ObjectModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using NoorAhlulBayt.Browser.Services;
using NoorAhlulBayt.Common.Models;
using NoorAhlulBayt.Common.Services;

namespace NoorAhlulBayt.Browser;

/// <summary>
/// Profile selection window for Islamic family-safe browser
/// </summary>
public partial class ProfileSelectionWindow : Window
{
    private readonly ProfileSelectionService _profileService;
    private readonly ObservableCollection<ProfileViewModel> _profiles;
    private ProfileViewModel? _selectedProfile;

    public ProfileSelectionWindow()
    {
        InitializeComponent();
        
        try
        {
            DiagnosticLogger.LogStartupStep("ProfileSelectionWindow constructor started");
            
            _profileService = new ProfileSelectionService();
            _profiles = new ObservableCollection<ProfileViewModel>();
            
            ProfilesItemsControl.ItemsSource = _profiles;
            
            DiagnosticLogger.LogStartupStep("ProfileSelectionWindow constructor completed");
        }
        catch (Exception ex)
        {
            DiagnosticLogger.LogError("ProfileSelectionWindow", "Error in constructor", ex);
            MessageBox.Show($"Error initializing profile selection: {ex.Message}", 
                          "Error", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private async void Window_Loaded(object sender, RoutedEventArgs e)
    {
        try
        {
            DiagnosticLogger.LogStartupStep("ProfileSelectionWindow loading profiles");
            await LoadProfilesAsync();
        }
        catch (Exception ex)
        {
            DiagnosticLogger.LogError("ProfileSelectionWindow", "Error loading profiles", ex);
            ShowNoProfilesMessage();
        }
    }

    private async Task LoadProfilesAsync()
    {
        try
        {
            ShowLoadingIndicator(true);
            
            var profiles = await _profileService.GetAvailableProfilesAsync();
            
            _profiles.Clear();
            
            if (profiles?.Any() == true)
            {
                var colors = new[] { "#4FC3F7", "#FFB74D", "#BA68C8", "#F06292", "#FFF176", "#81D4FA" };
                int colorIndex = 0;
                
                foreach (var profile in profiles)
                {
                    var viewModel = new ProfileViewModel
                    {
                        Id = profile.Id,
                        Name = profile.Name,
                        Description = profile.Description ?? GetDefaultDescription(profile),
                        AvatarIcon = profile.AvatarIcon ?? "👤",
                        AvatarColor = new SolidColorBrush((Color)ColorConverter.ConvertFromString(colors[colorIndex % colors.Length])),
                        RequiresPin = !string.IsNullOrEmpty(profile.EncryptedPin),
                        Profile = profile
                    };
                    
                    _profiles.Add(viewModel);
                    colorIndex++;
                }
                
                ShowLoadingIndicator(false);
                DiagnosticLogger.LogStartupStep($"Loaded {_profiles.Count} profiles");
            }
            else
            {
                ShowLoadingIndicator(false);
                ShowNoProfilesMessage();
                DiagnosticLogger.LogStartupStep("No profiles found");
            }
        }
        catch (Exception ex)
        {
            ShowLoadingIndicator(false);
            ShowNoProfilesMessage();
            DiagnosticLogger.LogError("ProfileSelectionWindow", "Error loading profiles", ex);
        }
    }

    private string GetDefaultDescription(UserProfile profile)
    {
        return profile.FilteringLevel switch
        {
            FilteringLevel.Child => "Child-safe browsing",
            FilteringLevel.Teen => "Teen-appropriate content",
            FilteringLevel.Adult => "Standard filtering",
            _ => "Safe browsing"
        };
    }

    private void ShowLoadingIndicator(bool show)
    {
        LoadingPanel.Visibility = show ? Visibility.Visible : Visibility.Collapsed;
        ProfilesItemsControl.Visibility = show ? Visibility.Collapsed : Visibility.Visible;
        NoProfilesPanel.Visibility = Visibility.Collapsed;
    }

    private void ShowNoProfilesMessage()
    {
        LoadingPanel.Visibility = Visibility.Collapsed;
        ProfilesItemsControl.Visibility = Visibility.Collapsed;
        NoProfilesPanel.Visibility = Visibility.Visible;
    }

    private async void SignInButton_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            if (sender is Button button && button.Tag is ProfileViewModel profile)
            {
                _selectedProfile = profile;
                
                if (profile.RequiresPin)
                {
                    // Show PIN input for this profile
                    ShowPinInputForProfile(button);
                }
                else
                {
                    // No PIN required, proceed directly
                    await AuthenticateAndProceedAsync(profile, null);
                }
            }
        }
        catch (Exception ex)
        {
            DiagnosticLogger.LogError("ProfileSelectionWindow", "Error in sign in", ex);
            MessageBox.Show($"Error signing in: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void ShowPinInputForProfile(Button signInButton)
    {
        try
        {
            // Find the PIN input and error message in the same card
            var border = FindParent<Border>(signInButton);
            if (border != null)
            {
                var pinInput = FindChild<PasswordBox>(border, "PinInput");
                var errorMessage = FindChild<TextBlock>(border, "ErrorMessage");
                
                if (pinInput != null)
                {
                    pinInput.Visibility = Visibility.Visible;
                    pinInput.Focus();
                    signInButton.Content = "Verify PIN";
                    
                    if (errorMessage != null)
                    {
                        errorMessage.Visibility = Visibility.Collapsed;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            DiagnosticLogger.LogError("ProfileSelectionWindow", "Error showing PIN input", ex);
        }
    }

    private async void PinInput_KeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key == Key.Enter && sender is PasswordBox pinInput && _selectedProfile != null)
        {
            await VerifyPinAndProceedAsync(pinInput, _selectedProfile);
        }
    }

    private async Task VerifyPinAndProceedAsync(PasswordBox pinInput, ProfileViewModel profile)
    {
        try
        {
            var pin = pinInput.Password;
            if (string.IsNullOrEmpty(pin))
            {
                ShowPinError(pinInput, "Please enter your PIN");
                return;
            }

            await AuthenticateAndProceedAsync(profile, pin);
        }
        catch (Exception ex)
        {
            DiagnosticLogger.LogError("ProfileSelectionWindow", "Error verifying PIN", ex);
            ShowPinError(pinInput, "Error verifying PIN");
        }
    }

    private async Task AuthenticateAndProceedAsync(ProfileViewModel profile, string? pin)
    {
        try
        {
            bool isAuthenticated = await _profileService.AuthenticateProfileAsync(profile.Id, pin);
            
            if (isAuthenticated)
            {
                DiagnosticLogger.LogStartupStep($"Profile authenticated: {profile.Name}");
                
                // Set the current profile
                await _profileService.SetCurrentProfileAsync(profile.Id);
                
                // Launch main browser window
                LaunchMainBrowser();
            }
            else
            {
                DiagnosticLogger.LogStartupStep($"Authentication failed for profile: {profile.Name}");
                
                if (profile.RequiresPin)
                {
                    var border = FindParent<Border>(ProfilesItemsControl);
                    if (border != null)
                    {
                        var pinInput = FindChild<PasswordBox>(border, "PinInput");
                        if (pinInput != null)
                        {
                            ShowPinError(pinInput, "Incorrect PIN. Please try again.");
                            pinInput.Clear();
                            pinInput.Focus();
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Authentication failed. Please try again.", 
                                  "Authentication Error", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
        }
        catch (Exception ex)
        {
            DiagnosticLogger.LogError("ProfileSelectionWindow", "Error in authentication", ex);
            MessageBox.Show($"Authentication error: {ex.Message}", 
                          "Error", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void ShowPinError(PasswordBox pinInput, string message)
    {
        try
        {
            var border = FindParent<Border>(pinInput);
            if (border != null)
            {
                var errorMessage = FindChild<TextBlock>(border, "ErrorMessage");
                if (errorMessage != null)
                {
                    errorMessage.Text = message;
                    errorMessage.Visibility = Visibility.Visible;
                }
            }
        }
        catch (Exception ex)
        {
            DiagnosticLogger.LogError("ProfileSelectionWindow", "Error showing PIN error", ex);
        }
    }

    private void LaunchMainBrowser()
    {
        try
        {
            DiagnosticLogger.LogStartupStep("Launching main browser window");
            
            var mainWindow = new MainWindow();
            mainWindow.Show();
            
            // Close the profile selection window
            this.Close();
        }
        catch (Exception ex)
        {
            DiagnosticLogger.LogError("ProfileSelectionWindow", "Error launching main browser", ex);
            MessageBox.Show($"Error launching browser: {ex.Message}", 
                          "Error", MessageBoxButton.OK, MessageBoxImage.Error);
        }
    }

    private void AdminButton_Click(object sender, RoutedEventArgs e)
    {
        try
        {
            // Launch companion app for admin settings
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo
            {
                FileName = "NoorAhlulBayt.Companion.exe",
                UseShellExecute = true
            });
        }
        catch (Exception ex)
        {
            DiagnosticLogger.LogError("ProfileSelectionWindow", "Error launching companion app", ex);
            MessageBox.Show("Could not launch admin settings. Please ensure the Companion app is installed.", 
                          "Error", MessageBoxButton.OK, MessageBoxImage.Warning);
        }
    }

    // Window control event handlers
    private void TitleBar_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ButtonState == MouseButtonState.Pressed)
        {
            this.DragMove();
        }
    }

    private void MinimizeButton_Click(object sender, RoutedEventArgs e)
    {
        this.WindowState = WindowState.Minimized;
    }

    private void CloseButton_Click(object sender, RoutedEventArgs e)
    {
        Application.Current.Shutdown();
    }

    // Helper methods for finding UI elements
    private static T? FindParent<T>(DependencyObject child) where T : DependencyObject
    {
        DependencyObject parentObject = VisualTreeHelper.GetParent(child);
        
        if (parentObject == null) return null;
        
        if (parentObject is T parent)
            return parent;
        
        return FindParent<T>(parentObject);
    }

    private static T? FindChild<T>(DependencyObject parent, string childName) where T : DependencyObject
    {
        if (parent == null) return null;

        T? foundChild = null;

        int childrenCount = VisualTreeHelper.GetChildrenCount(parent);
        for (int i = 0; i < childrenCount; i++)
        {
            var child = VisualTreeHelper.GetChild(parent, i);
            
            if (child is T typedChild && (child as FrameworkElement)?.Name == childName)
            {
                foundChild = typedChild;
                break;
            }

            foundChild = FindChild<T>(child, childName);
            if (foundChild != null) break;
        }

        return foundChild;
    }
}

/// <summary>
/// View model for profile display
/// </summary>
public class ProfileViewModel
{
    public int Id { get; set; }
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string AvatarIcon { get; set; } = "👤";
    public SolidColorBrush AvatarColor { get; set; } = new SolidColorBrush(Colors.Gray);
    public bool RequiresPin { get; set; }
    public UserProfile Profile { get; set; } = null!;
}
